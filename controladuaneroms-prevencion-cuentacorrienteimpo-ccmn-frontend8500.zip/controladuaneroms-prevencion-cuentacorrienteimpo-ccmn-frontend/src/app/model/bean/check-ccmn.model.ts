export class CheckCcmn {
  correlativoCcmn!: number;
  cntSeriesDcl!: number;
  cntArchivosAdjuntos!: number;
}
