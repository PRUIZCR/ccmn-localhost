export class Archivo {
  codArchivoECM!: string;
  nomArchivo!: string;
  nomContentType!: string;
  valArchivoBase64!: string;
}
