import { Injectable } from '@angular/core';
import { BehaviorSubject,of, EMPTY, Observable, throwError } from 'rxjs';
import { ArchivoCcmn } from '../model/bean/archivo-ccmn.model';
import { Ccmn } from '../model/domain/ccmn.model';
import { DamSerieCcmn } from '../model/domain/dam-serie-ccmn.model';



import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from 'src/environments/environment'; 
import { ConstantesApp } from '../utils/constantes-app';
import { map, catchError} from 'rxjs/operators';
import { SerieDeclaracionDpmn } from '../model/domain/serie-declaracion';
import { DocumentoAdjuntoDpmn } from '../model/domain/adjunto-dpmn.model';
import { Estado } from '../model/common/Estado';
import { Respuesta } from '../model/common/Respuesta';
@Injectable()
export class BuscarCcmnService {

  private URL_RESOURCE_CONSULTA_CCMN: string = environment.urlBaseIntranet + ConstantesApp.RESOURCE_ENDPOINT_CCMN;
  private URL_RESOURCE_DOCUMENTO_ADJUNTO_CCMN_LOCALPRUEBAS: string = "http://localhost:7109" + "/v1/controladuanero/prevencion/cuentacorrienteimpo/e/ccmns/";
  private URL_RESOURCE_ARCHIVOS_ADJUNTOS: string = environment.urlBase + ConstantesApp.RESOURCE_DATOS_DECLARACION;
  //private URL_RESOURCE__DATOS_SERIES_DECLARACION: string = environment.urlBase + ConstantesApp.RESOURCE_ENDPOINT_DAM_SERIES_CCMN;
  private URL_RESOURCE__DATOS_SERIES_DECLARACION : string ='http://localhost:7109'+ '/v1/controladuanero/prevencion/cuentacorrienteimpo/e/ccmns/';
 
  private rptCcmns : Respuesta<Ccmn[]> = Respuesta.create(new Array, Estado.LOADING);
  private rptCcmnSource = new BehaviorSubject<Respuesta<Ccmn[]>>(new Respuesta<Ccmn[]>());
  public rptBuscarCcmn$ = this.rptCcmnSource.asObservable();
 
 
  constructor(private http: HttpClient) { }

  /**
   * Busca una CCMN por su correlativo
   * @param correlativoCcmn Correlativo de la CCMN
   */
  //  buscar(correlativoCcmn: number) : Observable<Ccmn> {
  //   //TODO Completar
  //   return EMPTY;
  // }
  buscar(numCorrelativo:  string | null){

    return this.http.get<Ccmn>
      (this.URL_RESOURCE_CONSULTA_CCMN + numCorrelativo)
      .pipe(
        map(
          (resp: Ccmn) => this.crearDocumentoCcmn(resp)
        )
      )
  }
  private crearDocumentoCcmn(resp:any){
    const documentosCCMN: Ccmn[] = [];

    Object.keys(resp).forEach(key=>{
        const docuDpmn:Ccmn=resp[key];
        documentosCCMN.push(docuDpmn);
    });
    return documentosCCMN;
  }

  /**
   * Busca las Series de la DAM asociadas a una CCMN
   * @param correlativoCcmn Correlativo de la CCMN
   */
  // buscarDamSeries(correlativoCcmn: number) : Observable<DamSerieCcmn> {
  //   //TODO Completar
  //   return EMPTY;
  // }
  getSeriesDeclaracionByNumcorredoc(numCorrelativo: string | null) {
    return this.http.get<DamSerieCcmn>
      (this.URL_RESOURCE__DATOS_SERIES_DECLARACION + numCorrelativo + "/damseriesccmn")
      .pipe(
        map(
        (resp: DamSerieCcmn) => this.crearSerieDeclaracionCcmn(resp)
        )
      )
  }
  private crearSerieDeclaracionCcmn(resp: any) {
    const SerieDeclaracionDpmn: DamSerieCcmn[] = [];
    Object.keys(resp).forEach(key => {
      const docCcmn: DamSerieCcmn = resp[key];
      SerieDeclaracionDpmn.push(docCcmn);
    });
    return SerieDeclaracionDpmn;
  }


  /**
   * Busca adjuntos asociados a una CCMN
   * @param correlativoCcmn Correlativo de la CCMN
   */
  // buscarAdjuntos(correlativoCcmn: number) : Observable<ArchivoCcmn> {
  //   //TODO Completar
  //   return EMPTY;
  // }


  getDocumentoAdjuntoByNumcorredoc(numCorrelativo: string | null) {

    return this.http.get<DocumentoAdjuntoDpmn>
      (this.URL_RESOURCE_ARCHIVOS_ADJUNTOS + numCorrelativo + "/" + "adjuntosdpmn")
      .pipe(
        map(
          (resp: DocumentoAdjuntoDpmn) => this.crearDocumentoAdjuntoDpmn(resp)
        )
      )
  }

  private crearDocumentoAdjuntoDpmn(resp: any) {
    const documentosAdjuntosDPMN: DocumentoAdjuntoDpmn[] = [];
    Object.keys(resp).forEach(key => {
      const docuAdjuntoDpmn: DocumentoAdjuntoDpmn = resp[key];
      // if(resp===null){  return []; }
      // docuDpmn.numCorrelativo=key;
      documentosAdjuntosDPMN.push(docuAdjuntoDpmn);
    });
    return documentosAdjuntosDPMN;
  }


}
