export class MsgConfirmarRectiCcmn {
  correlativoEvento!: string;
  correlativoCcmn!: number;
}
