import { Injectable } from '@angular/core';
import { EMPTY, Observable } from 'rxjs';
import { ArchivoCcmn } from '../model/bean/archivo-ccmn.model';
import { Ccmn } from '../model/domain/ccmn.model';
import { DamSerieCcmn } from '../model/domain/dam-serie-ccmn.model';

@Injectable()
export class BuscarCcmnService {
  constructor() { }

  /**
   * Busca una CCMN por su correlativo
   * @param correlativoCcmn Correlativo de la CCMN
   */
  buscar(correlativoCcmn: number) : Observable<Ccmn> {
    //TODO Completar
    return EMPTY;
  }

  /**
   * Busca las Series de la DAM asociadas a una CCMN
   * @param correlativoCcmn Correlativo de la CCMN
   */
  buscarDamSeries(correlativoCcmn: number) : Observable<DamSerieCcmn> {
    //TODO Completar
    return EMPTY;
  }

  /**
   * Busca adjuntos asociados a una CCMN
   * @param correlativoCcmn Correlativo de la CCMN
   */
  buscarAdjuntos(correlativoCcmn: number) : Observable<ArchivoCcmn> {
    //TODO Completar
    return EMPTY;
  }

}
