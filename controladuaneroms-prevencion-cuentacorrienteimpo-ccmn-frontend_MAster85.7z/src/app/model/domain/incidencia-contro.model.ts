import { ActaControl } from "./acta-control.model";
import { Auditoria } from "./auditoria.model";

export class IncidenciaControl{
    desObservacion!: string;
    auditoria!: Auditoria;
    actaControl!: ActaControl[];
}