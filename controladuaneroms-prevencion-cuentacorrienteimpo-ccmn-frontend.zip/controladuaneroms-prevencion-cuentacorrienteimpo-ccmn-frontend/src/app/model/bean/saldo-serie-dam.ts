export class SaldoSerieDam {
 
  cntSaldo!: number;
  numSecDescarga!: number;
  numSerie!: number;
}
