export class PerfilUsuario {

  codUsuario!: string;
  codPerfil!: string;
  nomPerfil!: string;


}
