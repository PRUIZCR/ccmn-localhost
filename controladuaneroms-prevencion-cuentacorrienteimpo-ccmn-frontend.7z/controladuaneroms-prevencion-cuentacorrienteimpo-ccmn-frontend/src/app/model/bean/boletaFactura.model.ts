export class BoletaFacturaMod {
  numeroRuc!:string;
  serieComprobante!:string;
  tipoComprobante!:string;
  numeroComprobante!:number;
  respuesta!:string;
}
