export class MsgConfirmarRectiCcmn {
  correlativoEvento!: string;
  correlativoDpmn!: number;
}
