export class Empredti {
  cempti!: string;
  dnombre!: string;
}
