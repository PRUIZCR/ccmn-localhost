import { DataCatalogo } from "../common/data-catalogo.model";

export class Responsable{
    tipoDocumentoRes!: DataCatalogo;
    numDocumentoRes!:string;
    nomResponsable!:string;
    apeResponsable!:string;
    valEmail!:string;
    numTelefono!:string;
}