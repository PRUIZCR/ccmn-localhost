export enum Estado {
  SUCCESS,
  ERROR,
  WARNING,
  LOADING
}
