import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ea-editccmn-motivo',
  templateUrl: './ea-editccmn-motivo.component.html',
  styleUrls: ['./ea-editccmn-motivo.component.scss']
})
export class EaEditccmnMotivoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
