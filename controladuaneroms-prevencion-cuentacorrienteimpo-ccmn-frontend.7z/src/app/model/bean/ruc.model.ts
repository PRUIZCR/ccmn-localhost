export class Ruc {
  numero!: string;
  razonSocial!: string;
  codEstado!: string;
  codCondicion!: string;
}
