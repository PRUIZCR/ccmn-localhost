export enum TipoNacionalidad {
  NACIONAL = "0",
  EXTRANJERO = "1"
}
