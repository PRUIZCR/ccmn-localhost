export class ParamBusqRangoFecha {
    fechaInicio!: Date;
    fechaFin!: Date;
   
  }