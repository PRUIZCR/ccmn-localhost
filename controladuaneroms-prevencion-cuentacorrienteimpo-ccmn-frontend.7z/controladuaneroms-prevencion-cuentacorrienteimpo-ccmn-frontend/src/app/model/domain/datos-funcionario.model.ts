export class datosFuncionario{
    codUorg!: string;
    nomApePaterno!: string;
    nomApeMaterno!: string;
    nombres!: string;
    dirCorreo!:string;
    codAduana!:string;
    codPersonal!: string;
    esDirectivoUUOO!: boolean;
}