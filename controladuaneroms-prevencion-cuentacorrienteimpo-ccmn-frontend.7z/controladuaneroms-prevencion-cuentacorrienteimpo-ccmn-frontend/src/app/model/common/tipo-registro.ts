export enum TipoRegistro {
    CARGA = "01",
    BUS = "02",
    PARTICULAR = "03",
    CAF = "04",
    TTA = "05"
}  