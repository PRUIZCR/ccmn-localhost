export class ParamBusqFuncionario {

  usuario!: string;
  codPtoControl!: string;
  tienePerfilJefeSupervisor!: boolean;
  aduana!:string;


}
