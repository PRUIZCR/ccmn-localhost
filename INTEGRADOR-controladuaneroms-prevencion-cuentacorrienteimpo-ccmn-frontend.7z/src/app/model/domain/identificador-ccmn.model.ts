export class IdentificadorCcmn {
  correlativo!: number;
  codAduana!: string;
  anio!: number;
  numero!: number;
  codPuestoControl!: string;
}
