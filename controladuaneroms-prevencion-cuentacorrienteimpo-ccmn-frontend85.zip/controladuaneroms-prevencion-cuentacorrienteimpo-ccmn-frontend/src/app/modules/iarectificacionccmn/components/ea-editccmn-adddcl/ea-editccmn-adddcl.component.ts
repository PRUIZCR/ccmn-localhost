import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ea-editccmn-adddcl',
  templateUrl: './ea-editccmn-adddcl.component.html',
  styleUrls: ['./ea-editccmn-adddcl.component.scss']
})
export class EaEditccmnAdddclComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
