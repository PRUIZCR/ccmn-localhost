export class PersonalSunat{
    nroRegistro!: string;
    nomApePaterno!: string;
    nomApeMaterno!: string;
    nombres!: string;
    codUorg!: string;
    codCargo!: string;
}