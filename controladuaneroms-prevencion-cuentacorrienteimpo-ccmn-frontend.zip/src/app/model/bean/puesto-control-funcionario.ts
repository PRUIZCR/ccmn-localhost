import { CatalogoItem } from "./catalogo-item";

export class PuestoControlFuncionario extends CatalogoItem {
  aduana!: CatalogoItem;
}
