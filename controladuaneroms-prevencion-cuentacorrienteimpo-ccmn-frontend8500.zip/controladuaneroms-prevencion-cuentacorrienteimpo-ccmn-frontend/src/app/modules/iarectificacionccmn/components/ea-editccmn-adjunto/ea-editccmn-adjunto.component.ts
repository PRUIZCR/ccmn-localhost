import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ea-editccmn-adjunto',
  templateUrl: './ea-editccmn-adjunto.component.html',
  styleUrls: ['./ea-editccmn-adjunto.component.scss']
})
export class EaEditccmnAdjuntoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
