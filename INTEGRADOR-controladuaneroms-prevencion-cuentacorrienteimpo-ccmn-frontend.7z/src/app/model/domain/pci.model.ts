import { DataCatalogo } from "../common/data-catalogo.model";
import { Auditoria } from "./auditoria.model";
import { DocumentoAsociado } from "./documento-asociado.model";
import { FuncionarioAduanero } from "./funcionario-aduanero.model";
import { IncidenciaControl } from "./incidencia-contro.model";
import { ManifiestoPasajero } from "./manifiesto-pasajero.model";
import { Ubigeo } from "./ubigeo.model";
import { Vehiculo } from "./vehiculo.model";

export class Pci {
    numCorrelativo!: number;
    aduana!: DataCatalogo;
    puestoControl!: DataCatalogo;
    annPci!: number;
    numPci!: number;
    fecInicioControl!: any;
    paisPlaca!: DataCatalogo;
    nomPlaca!: string;
    flujoVehiculo!: DataCatalogo;
    motivoViaje!: DataCatalogo;
    estado!: DataCatalogo;
    tipoControl!: DataCatalogo;
    paisPlacaCarreta!: DataCatalogo;
    nomPlacaCarreta!: string;
    ubigeoDestino!: Ubigeo;
    jurisdiccionConvenio!: DataCatalogo;
    fecFinControl!: any;
    auditoria!: Auditoria;
    funcionarioAduanero!: FuncionarioAduanero;
    documentoAsociadoControl!: DocumentoAsociado[];
    manifiestoPasajero!: ManifiestoPasajero;
    incidenciaControl!: IncidenciaControl;
    vehiculo!: Vehiculo;
}