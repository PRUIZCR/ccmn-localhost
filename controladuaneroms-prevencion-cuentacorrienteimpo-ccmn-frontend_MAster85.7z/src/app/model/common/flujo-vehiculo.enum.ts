export enum FlujoVehiculo {
  CARGA = "01",
  BUS = "02",
  PARTICULAR = "03"
}
