export enum TipoEntidadNegocio {
    DPMNS = "dpmns",
    DAM_SERIES_DPMN = "damSeriesDpmn",
    ADJUNTOS_DPMN = "adjuntosDpmn"
}
