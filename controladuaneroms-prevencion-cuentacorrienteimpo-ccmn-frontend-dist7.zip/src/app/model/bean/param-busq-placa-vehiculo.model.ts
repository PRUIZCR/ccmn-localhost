export class ParamBusqPlacaVehiculo {
    codPais!: string;
    numero!: string;
  }