import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ea-editccmn-datostransp',
  templateUrl: './ea-editccmn-datostransp.component.html',
  styleUrls: ['./ea-editccmn-datostransp.component.scss']
})
export class EaEditccmnDatostranspComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
