import { Component, OnInit} from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { TokenAccesoService } from './services/token-acceso.service';
import { MessageService} from 'primeng/api';
import { CargaComponentesService } from './services/carga-componentes.service';
import { UbicacionFuncionario } from './model/bean/ubicacion-funcionario';
import { UbicacionFuncionarioService } from './services/ubicacion-funcionario.service';
import { RegistroCcmnService } from './services/registro-ccmn.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [MessageService]
})
export class AppComponent implements OnInit{
  title = 'controladuaneroms-prevencion-cuentacorrienteimpo-ccmn-frontend';

  constructor(private activateRoute: ActivatedRoute,
    private router: Router,
    private tokenAccesoService: TokenAccesoService,
    private cargaComponentes: CargaComponentesService,
    private ubicacionFuncionarioService: UbicacionFuncionarioService,
    private registroCcmnService: RegistroCcmnService) { }

  ngOnInit(): void {
    this.activateRoute.queryParams
    .subscribe(params => {
        let hayToken : boolean = params.token != null;
        let hayParamP : boolean = params.p != null;
      let hayComponente: boolean = params.componente != null;
		let noHayModulo : boolean = params.modulo == null;

      if (hayComponente && hayToken) {
        this.tokenAccesoService.guardarTokenSession(params.token);
        this.getDatosFuncionario(params);      
        return;
      }

        if ( hayToken ) {
          this.tokenAccesoService.guardarTokenSession(params.token);
        	if ( noHayModulo ) {
          		this.router.navigate(['/iaregistroccmn/registroccmn']);
        	}

        	if ( params.modulo == 'iarectificacionccmn' ) {
          		this.router.navigate(['/iarectificacionccmn/buscar-ccmn']);
        	}
        }

        if ( !hayToken && hayParamP ) {
          this.router.navigate(['/iaregistroccmn/registroccmn']);
        }

      }
    );
  }

  getDatosFuncionario(params: Params){
    let nroRegistro: string = this.tokenAccesoService.nroRegistro as string;

    this.ubicacionFuncionarioService.buscar(nroRegistro).subscribe((ubicacion: UbicacionFuncionario) => {
      if(ubicacion == undefined || ubicacion == null)
        return;

      this.registroCcmnService.datosFuncionario = ubicacion;
      this.cargaComponentes.guardarNumCorrePci(params.numCorrePci);
      this.cargaComponentes.cargarConfirmacionDeDpmn(ubicacion);

    });

  }

}
