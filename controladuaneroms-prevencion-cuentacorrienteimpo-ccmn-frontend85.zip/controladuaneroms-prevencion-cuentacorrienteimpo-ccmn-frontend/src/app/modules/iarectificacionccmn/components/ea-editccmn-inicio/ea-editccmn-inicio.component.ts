import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ea-editccmn-inicio',
  templateUrl: './ea-editccmn-inicio.component.html',
  styleUrls: ['./ea-editccmn-inicio.component.scss']
})
export class EaEditccmnInicioComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
