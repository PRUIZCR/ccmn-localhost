import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'saltoLinea'
})
export class SaltoLineaPipe implements PipeTransform {

  transform(value: any): string {
    if (value !== undefined && value !== null) {
      return value.toString().replace(/(.{49})/g, "$1 ");
    } else {
      return "";
    }
  }
}
