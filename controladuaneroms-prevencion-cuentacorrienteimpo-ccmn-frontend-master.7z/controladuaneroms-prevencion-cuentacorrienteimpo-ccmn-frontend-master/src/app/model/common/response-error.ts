export class RespuestaError{
    cod!:number;
    msg!:string;
}