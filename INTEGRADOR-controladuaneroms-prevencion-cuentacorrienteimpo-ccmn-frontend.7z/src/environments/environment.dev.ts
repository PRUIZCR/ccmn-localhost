export const environment = {
  production: false,
  urlBase: 'https://api-intranet.sunat.peru',
  urlComponentPCI: '..pci'
  //urlComponentPCI: 'http://localhost:4400'
};
