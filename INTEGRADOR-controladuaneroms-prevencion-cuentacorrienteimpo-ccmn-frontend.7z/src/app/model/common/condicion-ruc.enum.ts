export enum CondicionRuc {
  NO_HABIDO = "12",
  NO_HALLADO = "20"
}
