import { Component, OnInit } from '@angular/core';
import { MessageService } from 'primeng/api';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { DamSerieDpmn } from 'src/app/model/domain/dam-serie-dpmn.model';

@Component({
  selector: 'app-dialog-recti-item',
  templateUrl: './dialog-recti-item.component.html',
  styleUrls: ['./dialog-recti-item.component.css'],
  providers: [MessageService]
})
export class DialogRectiItemComponent implements OnInit {

  damSerieDpmn! : DamSerieDpmn;

  constructor(private config: DynamicDialogConfig,
              private messageService: MessageService,
              public ref: DynamicDialogRef) { }

  ngOnInit(): void {
    this.damSerieDpmn = this.config.data?.damSerieDpmn;
  }

  cancelar() : void {
    this.ref.close();
  }

  editar( valor : string ) : void {
    let noHayValor : boolean = valor == null || valor.trim().length <= 0;

    if ( noHayValor ) {
      this.mostrarMensaje('La cantidad retirada debe ser mayor a cero');
      return;
    }

    let cntRetirada : number = Number(valor);

    let sobrePasaCantidad : boolean = cntRetirada > this.damSerieDpmn.cntUnidadFisica;

    if ( sobrePasaCantidad ) {
      this.mostrarMensaje('La cantidad retirada excede la cantidad declarada de la serie');
      return;
    }

    this.damSerieDpmn.cntRetirada = cntRetirada;
    this.ref.close();
  }

  private mostrarMensaje(mensaje: string) {
    this.messageService.clear();
    this.messageService.add({severity:"warn", summary: 'Mensaje', detail: mensaje});
  }

}
