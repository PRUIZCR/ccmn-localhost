import { DataCatalogo } from "../common/data-catalogo.model";
import { FuncionarioAduanero } from "../domain/funcionario-aduanero.model";
import { Informe } from "./informe.model";

export class Sustento {
  motivo!: DataCatalogo[];
  observaciones?: string;
  jefeAutoriza!: FuncionarioAduanero;
  informe!: Informe;
}
