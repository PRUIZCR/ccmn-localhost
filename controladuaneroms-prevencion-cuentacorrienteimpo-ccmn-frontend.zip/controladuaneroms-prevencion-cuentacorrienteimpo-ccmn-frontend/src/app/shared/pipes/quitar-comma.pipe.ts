import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'quitarComma'
})
export class QuitarCommaPipe implements PipeTransform {

  transform(value: any): string {
    if (value !== undefined && value !== null) {
      return value.toString().replace(/,/g, "");
    } else {
      return "";
    }
  }
}
