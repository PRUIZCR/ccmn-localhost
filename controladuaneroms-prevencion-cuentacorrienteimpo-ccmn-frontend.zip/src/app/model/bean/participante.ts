import { DocIdentidad } from "./doc-identidad";

export class Participante {
  docIdentidad!: DocIdentidad;
  nombre!: string;
}
