export class IdentificadorDpmn {
  correlativo!: number;
  codAduana!: string;
  anio!: number;
  numero!: number;
}
