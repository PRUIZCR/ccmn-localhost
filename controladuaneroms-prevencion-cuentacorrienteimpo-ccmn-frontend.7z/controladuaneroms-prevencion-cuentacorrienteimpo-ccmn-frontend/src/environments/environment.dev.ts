export const environment = {
  production: false,
  urlBase: 'https://api-intranet.sunat.peru',
  urlComponentPCI: '../pci',
  urlLocalPci: 'http://localhost:4400'
  //urlComponentPCI: 'http://localhost:4400'
};
