export class Entvehiculo {
  cpaisPlaca!: string;
  cplaca!: string;
}
