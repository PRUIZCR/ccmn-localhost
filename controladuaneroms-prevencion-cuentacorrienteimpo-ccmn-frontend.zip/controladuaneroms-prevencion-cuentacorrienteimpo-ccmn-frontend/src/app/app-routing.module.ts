import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import {AppComponent} from './app.component';
import { DetalleComponent } from './modules/registroccmn/components/guardarccmn-carga/detalle-dpmn.component';


const routes: Routes = [
  { path: 'iaregistroccmn', loadChildren: () =>
      import('./modules/registroccmn/registroccmn.module').
          then(m => m.RegistroccmnModule)
  },
  { path: 'confirmarccmnpci', component: DetalleComponent, loadChildren: () =>
    import('./modules/registroccmn/registroccmn.module').
      then(m => m.RegistroccmnModule)
  },
  { path: 'iarectificacionccmn', loadChildren: () =>
      import('./modules/iarectificacionccmn/iarectificacionccmn.module').
          then(m => m.IarectificacionccmnModule)
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
