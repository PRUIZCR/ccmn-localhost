import { DataCatalogo } from "../common/data-catalogo.model";
import { ControlViaje } from "./control-viaje.model";

export class Vehiculo{
    paisPlaca!: DataCatalogo;
    nomPlaca!: string;
    marca!: DataCatalogo;
    modelo!: DataCatalogo;
    chasis!: string;
    motor!: string;
    controlViaje!: ControlViaje;
}