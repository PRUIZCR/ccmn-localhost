export const environment = {
  production: true,
  urlBase: 'https://api-intranet.sunat.peru'
};
