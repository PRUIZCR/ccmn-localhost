import { Ubigeo } from "../domain/ubigeo.model";

export class DatoComplementario {
  ubigeoOrigen!: Ubigeo;
  desObservacion!: string;
}
