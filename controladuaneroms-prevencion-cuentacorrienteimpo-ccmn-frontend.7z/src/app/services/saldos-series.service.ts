import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { ConstantesApp } from '../utils/constantes-app';
import { DamSerieCcmn } from '../model/domain/dam-serie-ccmn.model';

@Injectable()
export class SaldoSeriesService {

  //private URL_RESOURCE_ENDPOINT_CCMN: string = environment.urlBase + ConstantesApp.RESOURCE_ENDPOINT_CCMN;
  private URL_RESOURCE_ENDPOINT_CCMN: string =  "http://localhost:7122//v1/controladuanero/prevencion/cuentacorrienteimpo/t/ccmn";
  constructor(private http: HttpClient) {}

  validarSaldoSeries(damSeriesCcmn: DamSerieCcmn[]) : Observable<any> {
    let url : string = this.URL_RESOURCE_ENDPOINT_CCMN + "/validargrabacion";
    return this.http.post<any>(url, damSeriesCcmn);
  }
}
