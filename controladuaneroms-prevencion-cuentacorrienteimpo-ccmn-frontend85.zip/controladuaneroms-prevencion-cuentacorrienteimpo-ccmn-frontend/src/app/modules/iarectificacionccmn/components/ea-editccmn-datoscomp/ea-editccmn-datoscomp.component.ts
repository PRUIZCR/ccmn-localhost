import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ea-editccmn-datoscomp',
  templateUrl: './ea-editccmn-datoscomp.component.html',
  styleUrls: ['./ea-editccmn-datoscomp.component.scss']
})
export class EaEditccmnDatoscompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
