import { Component, OnInit} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TokenAccesoService } from './services/token-acceso.service';
import { MessageService} from 'primeng/api';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [MessageService]
})
export class AppComponent implements OnInit{
  title = 'controladuaneroms-prevencion-cuentacorrienteimpo-ccmn-frontend';

  constructor(private activateRoute: ActivatedRoute,
    private router: Router,
    private tokenAccesoService: TokenAccesoService) { }

  ngOnInit(): void {
    this.activateRoute.queryParams
    .subscribe(params => {
        let hayToken : boolean = params.token != null;
        let hayParamP : boolean = params.p != null;

        if ( hayToken ) {
          this.tokenAccesoService.guardarTokenSession(params.token);
          this.router.navigate(['/iaregistroccmn/registroccmn']);
        }

        if ( !hayToken && hayParamP ) {
          this.router.navigate(['/iaregistroccmn/registroccmn']);
        }

      }
    );
  }
}
