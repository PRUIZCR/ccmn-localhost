import { Auditoria } from "../domain/auditoria.model";

export class ArchivoCcmn {
  id!: number;
  numCorrelativoCcmn!: number;
  numeroCcmn!: string;
  codAduanaCcmn!: string;
  annioCcmn!: string;
  codTipoDocumento!: string;
  desTipoDocumento!: string;
  origenInvocacion!: string;
  usuarioRegistra!: string;
  nomArchivo!: string;
  nomContentType!: string;
  valArchivoBase64!: string;
  fecRegistro!: Date;
  fechaRegistro!: Date;
  indEliminado!: boolean;
  auditoria!:Auditoria;
  codArchivoEcm!: string;
}
