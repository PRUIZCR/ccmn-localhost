import { DataCatalogo } from "../common/data-catalogo.model";

export class ActaControl{
    numSecuencia!: number;
    aduana!: DataCatalogo;
    puestoControl!: DataCatalogo;
    annActa!: number;
    numActa!: number;
    tipoActa!: DataCatalogo;
    fecActa!: any;
    indValidacion!: number;
}