export class DocumentoAdjuntoCcmn {
  codArchivoEcm!: string;
  numCorrelativoCcmn!: number;
  codTipoDocumento!: string;
  desTipoDocumento!: string;
  nomArchivo!: string;
  nomContentType!: string;
  fecRegistro!: any;
  indEliminado!: boolean;
}
