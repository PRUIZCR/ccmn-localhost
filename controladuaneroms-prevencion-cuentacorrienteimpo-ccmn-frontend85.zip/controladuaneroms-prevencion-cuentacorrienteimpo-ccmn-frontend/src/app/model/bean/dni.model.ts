export class Dni {
  frmBusqueda!:string;
  numero!: string;
  nombres!: string;
  apellidos!: string;
}
