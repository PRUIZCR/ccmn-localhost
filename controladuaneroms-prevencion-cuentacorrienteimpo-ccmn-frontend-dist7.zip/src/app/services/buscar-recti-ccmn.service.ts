import { Inject, Injectable } from '@angular/core';
import { BehaviorSubject, EMPTY, Observable, of, throwError } from 'rxjs';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Respuesta } from '../model/common/Respuesta';
import { Estado } from '../model/common/Estado';
import { DataCatalogo } from '../model/common/data-catalogo.model';
import { ParamBusqCcmnParaRectificar } from '../model/bean/param-busq-ccmn-para-rectificar.model';
import { ItemCcmnParaRectificar } from '../model/bean/item-ccmn-para-rectificar.model';

import { map, catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { Auditoria } from '../model/domain/auditoria.model';
import { ConstantesApp } from '../utils/constantes-app';


@Injectable()
export class BuscarRectiCcmnService {
  private URL_RESOURCE_BUSQUEDA_CCMN : string =  environment.urlBase + ConstantesApp.RESOURCE_CONSULTA_RECTI_CCMN;

  private rptaBusqDclSource = new BehaviorSubject<Respuesta<ItemCcmnParaRectificar[]>>(new Respuesta<ItemCcmnParaRectificar[]>());
  

  public rptaBusqDcl$ = this.rptaBusqDclSource.asObservable();
 
  public rptaListaCtrlCcmns!: ItemCcmnParaRectificar[] ;

  public itemCcmn!: ItemCcmnParaRectificar;


  constructor(private http: HttpClient 


  ) { }

  buscarParaRectificar( paramBusqDpmnRecti : ParamBusqCcmnParaRectificar ) : void {
    
    this.rptaBusqDclSource.next(Respuesta.create(new Array, Estado.LOADING));
    console.log("1ero")

    this.validarDpmnsHttp(paramBusqDpmnRecti).subscribe((respuesta : Respuesta<ItemCcmnParaRectificar[]>) => {
      this.rptaBusqDclSource.next(respuesta);
      this.rptaListaCtrlCcmns = respuesta.data;
      console.log("2do")
    });

  };

  private validarDpmnsHttp( paramBusqCcmnRecti : ParamBusqCcmnParaRectificar ): Observable<Respuesta<ItemCcmnParaRectificar[]>> {
    return this.http.post<any>(this.URL_RESOURCE_BUSQUEDA_CCMN, paramBusqCcmnRecti).pipe(
          map(ccmns => {

            if ( ccmns == null ) {
              return Respuesta.create(new Array, Estado.SUCCESS);
            }

            var lstItemCcmnParaRectificar : ItemCcmnParaRectificar[]  = new Array();

            ccmns.forEach((itemCcmn : any) => {

              var newCcmm = new ItemCcmnParaRectificar();
              newCcmm.correlativoCcmn = itemCcmn?.correlativoCcmn;
              newCcmm.numeroCcmn = itemCcmn?.numeroCcmn  ;
              newCcmm.paisPlaca = new DataCatalogo();
              newCcmm.paisPlaca = itemCcmn?.paisPlaca;
              newCcmm.nomPlaca = itemCcmn?.nomPlaca;
              newCcmm.paisPlacaCarreta = new DataCatalogo();
              newCcmm.paisPlacaCarreta = itemCcmn?.paisPlacaCarreta;
              newCcmm.nomPlacaCarreta = itemCcmn?.nomPlacaCarreta;
              newCcmm.flujoVehiculo = new DataCatalogo();
              newCcmm.flujoVehiculo = itemCcmn?.flujoVehiculo;
              newCcmm.auditoria = new Auditoria();
              newCcmm.auditoria = itemCcmn?.auditoria;
              //newCcmm.actorRegistro =  new DataCatalogo();
              //newCcmm.actorRegistro =itemCcmn?.actorRegistro;
              lstItemCcmnParaRectificar.push(newCcmm);
            });

        return Respuesta.create(lstItemCcmnParaRectificar, Estado.SUCCESS);
      }),
      catchError((error: HttpErrorResponse) => {
        console.error(error);
        this.rptaBusqDclSource.next(Respuesta.createFromErrorHttp(error));
        return throwError(error);
        })
    );
  }

  limpiarData() : void {
		this.itemCcmn = new  ItemCcmnParaRectificar();
    this.rptaBusqDclSource.next(Respuesta.create(new Array, Estado.LOADING));
	}


}
