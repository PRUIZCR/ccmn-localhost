export class Auditoria {
fecRegis!: Date;
codUsuRegis!: string;
fecModif!: Date;
codUsumodif!: string;
}
