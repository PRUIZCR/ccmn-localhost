import { DataCatalogo } from "../common/data-catalogo.model";

export class DocumentoAsociado{
    numCorrelativoDocumento!: number;
    codTipoDocumento!: string;
    aduanaDocumento!: DataCatalogo;
    annDocumento!: number;
    numDocumento!: number;
    puestoControlDocumento!: DataCatalogo;
    fecDocumento!: any;
}