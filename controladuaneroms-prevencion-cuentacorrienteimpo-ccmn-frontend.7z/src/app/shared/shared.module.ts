import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SelectFromJsonComponent } from './components/select-from-json/select-from-json.component';
import { QuitarCommaPipe } from './pipes/quitar-comma.pipe'
import { CargarJsonDirective } from './directives/cargar-json.directive';
import { SaltoLineaPipe } from './pipes/salto-linea.pipe';
//import { IconFlujoVehiculoComponent } from './components/icon-flujo-vehiculo/icon-flujo-vehiculo.component'


import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { KeyFilterModule } from 'primeng/keyfilter';
import { ToastModule } from 'primeng/toast';

@NgModule({
  declarations: [
    SelectFromJsonComponent,
    CargarJsonDirective,
    QuitarCommaPipe,
    SaltoLineaPipe,
    //IconFlujoVehiculoComponent
  ],
  imports: [
    CommonModule,
    ToastModule,
    DynamicDialogModule,
    KeyFilterModule
  ],
  exports: [
    SelectFromJsonComponent,
    CargarJsonDirective,
    QuitarCommaPipe,
    SaltoLineaPipe,
    //IconFlujoVehiculoComponent
  ]
})
export class SharedModule { }
