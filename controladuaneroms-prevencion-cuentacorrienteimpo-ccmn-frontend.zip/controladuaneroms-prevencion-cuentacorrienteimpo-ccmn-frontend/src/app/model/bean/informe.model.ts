export class Informe {
  area!: string;
  anio!: number;
  numero!: string;
}
