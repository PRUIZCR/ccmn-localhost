export const environment = {
  production: false,
  urlBase: 'https://api-intranet.sunat.peru'
};
