export class MensajeBean {
  cod!: number;
  msg!: string;
}
