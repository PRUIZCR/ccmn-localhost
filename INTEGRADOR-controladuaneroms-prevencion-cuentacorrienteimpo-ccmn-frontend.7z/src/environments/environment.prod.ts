export const environment = {
  production: true,
  urlBase: 'https://api-intranet.sunat.peru',
  urlComponentPCI: '../pci'
  //urlComponentPCI: 'http://localhost:4400'
};
