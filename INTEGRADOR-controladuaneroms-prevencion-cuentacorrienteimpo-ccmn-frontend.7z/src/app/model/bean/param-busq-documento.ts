export class ParamBusqDocumento {
  codAduana!: string;
  anio!: number;
  numero!: number;
  
}