import { DataCatalogo } from "../common/data-catalogo.model";
import { Ubigeo } from "./ubigeo.model";

export class ControlViaje{
    aduana!: DataCatalogo;
    convenio!: DataCatalogo;
    annViaje!: number;
    numViaje!: number;
    puestoControl!: DataCatalogo;
    ubigeoDestino!: Ubigeo;
    jurisdiccionConvenio!: DataCatalogo;
    fecInicioViaje!: any;
    fecVencimiento!: any;
}