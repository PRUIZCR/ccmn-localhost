export class ChkEstadoEvento {
  correlativo!: string;
  cantidad!: number;
  procesado!: boolean;
  anulado!: boolean;
}
  