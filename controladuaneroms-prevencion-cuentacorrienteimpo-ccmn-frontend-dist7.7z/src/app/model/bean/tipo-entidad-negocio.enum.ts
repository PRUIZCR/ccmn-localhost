export enum TipoEntidadNegocio {
    DPMNS = "CCMNS",
    DAM_SERIES_DPMN = "DAM_SERIES_CCMN",
    ADJUNTOS_DPMN = "ADJUNTOS_CCMN"
}
