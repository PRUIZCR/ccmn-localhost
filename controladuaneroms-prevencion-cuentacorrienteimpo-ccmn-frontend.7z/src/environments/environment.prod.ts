export const environment = {
  production: true,
  urlBase: 'https://api-intranet.sunat.peru',
  urlComponentPCI: '../pci',
  urlLocalPci: 'http://localhost:4200'
  //urlComponentPCI: 'http://localhost:4200'
};
